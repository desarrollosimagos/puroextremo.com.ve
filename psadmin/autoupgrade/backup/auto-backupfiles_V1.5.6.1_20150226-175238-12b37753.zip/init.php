php_value suhosin.post.max_vars 10000
php_value suhosin.request.max_vars 10000