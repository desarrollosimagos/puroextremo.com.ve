<?php
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'extremo_boutique');
define('_DB_USER_', 'extremo_puro');
define('_DB_PASSWD_', 'G8m&lIGJ3V@R');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheFs');
define('_PS_CACHE_ENABLED_', '1');
define('_MEDIA_SERVER_1_', '');
define('_MEDIA_SERVER_2_', '');
define('_MEDIA_SERVER_3_', '');
define('_COOKIE_KEY_', '58T6Jx4735RVG5kOtkjq6tSrFrwKBpgI1O0pABBs52Q9fMXXmYm9O2Fy');
define('_COOKIE_IV_', 'ak0RMwup');
define('_PS_CREATION_DATE_', '2013-05-12');
define('_PS_VERSION_', '1.5.6.1');
define('_RIJNDAEL_KEY_', 'TRa7TcKdnBaWTztsa89gPVLm5FeCyFue');
define('_RIJNDAEL_IV_', 'i/SYCifjZtjf9bRA3fNsxg==');